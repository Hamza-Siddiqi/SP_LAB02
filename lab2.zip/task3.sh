showAll()
{
for i in `ls`
do

name=(`ls -o $i`)
if [ ${name[2]} = $1 ]
then
echo ${name[2]} $i
fi
done
}
if [ $# = 0 ]
then
echo "Invalid!No argument given"
elif [ $# -gt 1 ]
then
echo "Invalid!Greater than 1 argument given"
elif [ $# -eq 1 ]
then
showAll $1
fi
