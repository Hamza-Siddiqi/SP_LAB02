rule1()
{
  echo "Invalid! No argument enter."
exit 0
}
rule2()
{
 echo "Invalid!arguments greater than 6 ."
exit 0
}
rule3()
{
   declare -i s
   declare -i var
   var=$1
   for i in `seq 1 10`
do
    s=$var\*$i
   echo $s  
done
}
rule4()
{
 declare -i s
 declare -i var
 var=$1
if [ $2 = "-s" ]
then
for i in `seq $3 10`
do
s=$var\*$i
echo $s

done
fi 
if [ $2 = "-e" ]
then
for i in `seq 1 $3`
do
s=$var\*$i
echo $s

done
fi 
}
rule6()
{

declare -i s
 declare -i var
 var=$1

for i in `seq $3 $5`
do
s=$var\*$i
echo $s

done

}
rule7()
{
declare -i s
declare -i start
declare -i e
 declare -i var
 var=$1
  e=$5 
start=$3
  
while [ $e -ge $start ] 
do
s=$var\*$e
e=`expr e-1`
echo $s

done

}
#Main  script

if [ $# -eq 0 ]
then
 rule1
elif [ $# -gt 6 ]
then
 rule2
elif [ $# -eq 1 ]
 then
   rule3 $1
elif [ $# -eq 3 ]
 then
    rule4 $1 $2 $3
elif [ $# -eq 5 ]
 then
    rule6 $1 $2 $3 $4 $5

elif [ $# -eq 6 ]
then

rule7 $1 $2 $3 $4 $5 $6







fi

