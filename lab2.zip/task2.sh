idd=`pidof $1`
cd /proc/$idd
cat status | grep "Pid"
cat status | grep "State"
cat status | grep "Name"
